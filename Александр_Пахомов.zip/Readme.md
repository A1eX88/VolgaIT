# Инструкция
1. ./mvnw -B package -DskipTests
2. cd target
3. java -jar webapp.jar
